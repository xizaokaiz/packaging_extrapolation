# 关于`packaging_extrapolation`
* 由于量子化学的计算成本与基组相关，其随着基组序列逐渐递增。
本工具库以文献提出的外推公式所编写，使用Python语言。
通过输入两个水平的能量即可达到CBS极限值。

## 安装方法
* 使用`pip`命令安装：`pip install packaging_extrapolation`
